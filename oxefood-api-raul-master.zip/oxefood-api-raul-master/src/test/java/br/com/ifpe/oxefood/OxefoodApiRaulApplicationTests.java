package br.com.ifpe.oxefood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OxefoodApiRaulApplicationTests {

	@Test
	void contextLoads() {
	}

}
